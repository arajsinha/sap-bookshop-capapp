sap.ui.define(["sap/fe/core/AppComponent"],function(o){"use strict";return o.extend("Bookshop.MyBookshop.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map